# ui-express-app
Sample NodeJS Express application for building UIs


## Building

```shell
npm install
```

## Running
```shell
npm start
```

## Testing
```shell
npm test
```


