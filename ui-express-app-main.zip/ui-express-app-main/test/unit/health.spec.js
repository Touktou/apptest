var assert = require('assert');

describe('Test /health', () => {
    describe('Health check on /sync', () => {
      it('health should be okay', () => {
        assert.ok(true);
      });
    });
});
